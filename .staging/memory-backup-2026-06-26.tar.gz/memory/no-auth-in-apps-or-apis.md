---
name: no-auth-in-apps-or-apis
description: "Apps and APIs are 100% public — no login, no auth code. Login lives in a separate \"login manager\" project, not embedded."
metadata: 
  node_type: memory
  type: project
  originSessionId: dfd8f5bc-c2a5-4696-91a4-ea972dce2c5f
---

- All apps in `repos/apps/*` are 100% public; no sign-in UI, no session check, no auth dependency.
- All APIs in `repos/apis/*` are 100% public; no API key check (use rate-limit-by-IP instead, see [[oriz-rate-limit-npm-pkg]]).
- A separate **login-manager** project exists (TBD: which repo, which subdomain) for cases where login IS needed. Apps/APIs that need a logged-in user redirect to it, never embed it.
- Why: simplifies every app shell, kills the cross-repo auth coupling, makes donation-only model coherent (donors don't need accounts).
- Why now: at 0 paying users, embedded auth is a tax with no revenue. The fleet's value prop is "free public tools" — auth flow is friction.
- Supersedes: [[auth-clerk-with-emergency-migrate]] (locked, then reversed same day).
- Supersedes: [[auth-firebase-login-and-account-subdomains]] (already superseded earlier today).
- Related: [[donations-only-no-pro-no-ads]], [[no-card-on-file-prepaid-escape]].
