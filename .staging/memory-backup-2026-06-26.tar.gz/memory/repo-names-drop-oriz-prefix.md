---
name: repo-names-drop-oriz-prefix
description: "Repo slugs drop the `oriz-` brand prefix. Service name only — `oriz-org/finance`, not `oriz-org/oriz-finance`. Org namespace provides branding."
metadata: 
  node_type: memory
  type: project
  originSessionId: dfd8f5bc-c2a5-4696-91a4-ea972dce2c5f
---

Fleet repo slugs are bare service names: `oriz-org/finance`, `oriz-org/text`, `oriz-org/login`. The `oriz-org/` namespace already brands them — prefixing the repo with `oriz-` is redundant. Refines [[repo-slug-suffix-npm-pkg]] (type-suffix still applies for npm packages: `foo-npm-pkg`). Locked 2026-06-25.
