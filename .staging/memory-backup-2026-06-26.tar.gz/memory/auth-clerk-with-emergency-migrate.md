---
name: auth-clerk-with-emergency-migrate
description: Clerk Auth for now; emergency-migrate to Firebase before crossing 5000 MAU on any app
metadata: 
  node_type: memory
  type: project
  originSessionId: dfd8f5bc-c2a5-4696-91a4-ea972dce2c5f
---

- Clerk for `login.oriz.in` (auth flow page) + `account.oriz.in` (`<UserProfile/>` widget).
- Hard trigger: when ANY single app crosses 5000 MAU (= 50% of Clerk's 10k cap), migrate auth to Firebase.
- App code MUST NOT import Clerk SDK except in the sign-in widget. JWT verified server-side by a CF Worker so the migration surface stays minimal.
- Why: Clerk's `<UserProfile/>` widget IS `account.oriz.in` for free (no code), Firebase needs hand-built dashboard.
- Why 5000 not 10k: gives time to migrate before card-on-file is forced.
- Supersedes [[auth-firebase-login-and-account-subdomains]].
- Related: [[no-card-on-file-prepaid-escape]], [[no-card-rule-veto-history]].

**SUPERSEDED 2026-06-25 (same day)** by [[no-auth-in-apps-or-apis]]. Reversed: NO auth in apps/APIs at all. Login moves to a separate project.
