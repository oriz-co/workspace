---
name: rules-centralized-at-umbrella-no-per-repo
description: All rules + .env.example live ONLY in the umbrella (oriz-org/workspace). Individual submodules have NO rules of their own. Reverses earlier per-repo rule.
metadata:
  type: feedback
---

ALL rules + `.env.example` live ONLY in the umbrella (`oriz-org/workspace` at `c:\D\oriz\`).

- Submodules: NO rules, NO `.env.example`. Just code + their own `.env` (if needed, gitignored).
- Umbrella: ONE canonical `.env.example` at root, ONE knowledge tree, ONE AGENTS.md.

Reverses [[env-example-mirrors-env-with-steps]] (deleted) + `submodule-env-files-three-file-pattern` (deleted from knowledge).

Why: simpler. One place to look. No drift across 20 submodules.

Related: [[knowledge-deletion-not-supersession]] — superseded files hard-deleted, not marked.
