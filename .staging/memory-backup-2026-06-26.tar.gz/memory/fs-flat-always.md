---
name: fs-flat-always
description: "All repos live at repos/<slug>/. Always flat, no category subdirs, regardless of count. Muscle memory wins over organization."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: dfd8f5bc-c2a5-4696-91a4-ea972dce2c5f
---

The 13-category nest was an organizing fiction. In day-to-day work you `cd repos/<slug>/` from muscle memory; you don't think about which category the slug belongs to. Categories live in GitHub topics and on `home.oriz.in/explore`, not in the filesystem.

**Captured:** 2026-06-25, after flip-flopping between flat → nested → flat in one session. Locking the rule to stop the loop.

**The rule:** every submodule lives at `repos/<slug>/`. No `repos/<category>/<slug>/`. No `repos/<category>-flat-shadow/`. Just flat.

**Why this beats both prior rules:**
- `fs-flat-over-nested` (2026-06-21): correct intuition, wrong rationale ("flat at <30 repos"). True reason is muscle memory, not count.
- `fs-nested-when-large-flat-when-small` (2026-06-25 morning): wrong from the start. Nesting created collisions (`packages/` app vs `npm-packages/` category) and forced awkward double-names (`userscripts/bundle`). 30 minutes after locking, reversed.

**Supersedes BOTH:**
- [[fs-flat-over-nested]]
- [[fs-nested-when-large-flat-when-small]]

**How to apply:**
- New repo → `repos/<slug>/`. Period.
- Category metadata lives in GitHub topics + `apps.ts` + future `explore` page. Not on disk.
- Slug naming still follows [[repo-slug-suffix-npm-pkg]] (`-api`, `-npm-pkg`, `-bs-ext`, `-cli`, etc.) — suffixes encode category, filesystem doesn't.

**Related:** [[polyrepo-with-category-consolidation]], [[github-repo-names-are-brand-identity]], [[knowledge-supersession-not-deletion]].
