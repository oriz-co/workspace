---
name: fleet-owner-oriz-org
description: "All fleet repos live under `oriz-org`. `chirag127` keeps personal-only repos. Use `gh repo transfer` to migrate fleet items found on chirag127."
metadata: 
  node_type: memory
  type: project
  originSessionId: dfd8f5bc-c2a5-4696-91a4-ea972dce2c5f
---

Canonical owner for every fleet repo is the `oriz-org` GitHub org. The `chirag127` personal account retains only personal-only repos (dotfiles, experiments, non-fleet). When a fleet repo is found on `chirag127`, run `gh repo transfer chirag127/<name> oriz-org` to migrate. Locked 2026-06-25.
