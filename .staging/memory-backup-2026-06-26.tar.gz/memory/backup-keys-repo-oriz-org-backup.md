---
name: backup-keys-repo-oriz-org-backup
description: "Private `oriz-org/backup` repo holds restic config + recovery keys (git-crypt encrypted) + RECOVERY.md. Snapshot data lives in B2, not the repo."
metadata: 
  node_type: memory
  type: project
  originSessionId: dfd8f5bc-c2a5-4696-91a4-ea972dce2c5f
---

Private repo `oriz-org/backup` (not public) stores: restic repo config, recovery keys (git-crypt encrypted with a GPG key), and `RECOVERY.md` step-by-step restore runbook. Actual snapshot data is in Backblaze B2, not in the repo. Pairs with [[backup-restic-b2-plus-windows-builtin]]. Locked 2026-06-25.
