---
name: build-gate-top3-must-have-defect
description: "Build a tool only when the top-3 Google results for the problem have a real defect (paywall, signup wall, ads, missing feature). README documents the defect."
metadata: 
  node_type: memory
  type: project
  originSessionId: dfd8f5bc-c2a5-4696-91a4-ea972dce2c5f
---

Gate for "should we build this tool": Google the problem, examine top-3 results. Build only if all three have a real defect — paywall, signup wall, ads-laden UI, broken UX, or a missing feature the user needs. Each tool's README opens with the specific defect (e.g., "smallpdf.com gates at 2 files/day; we don't"). Locked 2026-06-25.
