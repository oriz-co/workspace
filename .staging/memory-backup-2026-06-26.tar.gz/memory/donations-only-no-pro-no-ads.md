---
name: donations-only-no-pro-no-ads
description: "Final monetization — donations only (BuyMeACoffee + GitHub Sponsors + UPI). No Pro tier, no ads, no premium. Razorpay killed."
metadata: 
  node_type: memory
  type: project
  originSessionId: dfd8f5bc-c2a5-4696-91a4-ea972dce2c5f
---

Every app footer shows three donate links: BuyMeACoffee, GitHub Sponsors, UPI QR. No Pro/Premium/Max tier exists anywhere. No ads. No paywalls. Razorpay checkout flow is killed entirely. Supersedes [[monetization-centralized-on-oriz-in]]. Locked 2026-06-25.
