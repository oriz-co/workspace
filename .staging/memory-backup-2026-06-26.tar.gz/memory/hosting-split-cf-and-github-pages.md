---
name: hosting-split-cf-and-github-pages
description: CF Pages hosts apps/PWAs/websites; GitHub Pages hosts software landing pages (CLI/extension/MCP/npm-pkg marketing). Both donation-OK.
metadata: 
  node_type: memory
  type: project
  originSessionId: dfd8f5bc-c2a5-4696-91a4-ea972dce2c5f
---

Cloudflare Pages = apps, PWAs, interactive websites (the surfaces users *use*). GitHub Pages = static marketing/landing pages for software (CLIs, browser extensions, MCP servers, npm-pkg docs). Both platforms' ToS permit donation buttons (BuyMeACoffee/Sponsors/UPI). Reverses earlier "everything on GitHub Pages" call. Refines [[cloudflare-pages-apps-only]]. Locked 2026-06-25.
