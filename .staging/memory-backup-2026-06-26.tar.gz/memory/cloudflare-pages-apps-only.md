---
name: cloudflare-pages-apps-only
description: CF Pages projects are for the 25 apps under projects/apps/ ONLY. Everything else uses GitHub Pages.
metadata: 
  node_type: memory
  type: project
  originSessionId: dfd8f5bc-c2a5-4696-91a4-ea972dce2c5f
---

CF Pages projects = projects/apps/ submodules only (hub/content/personal/tools). All other surface area — npm packages, APIs, books, extensions, skills, forks, data repos — lives on GitHub Pages instead. Non-app subdomains that want a "for more info" landing page link to oriz.in. Total 26 CF Pages projects (25 apps + www.oriz.in shares oriz-app). Refines [[cloudflare-pages-hosts-every-website-and-app]]. Decision: knowledge/rules/cloudflare-pages-apps-only.md. Locked 2026-06-23.

**REFINED 2026-06-25** by [[hosting-split-cf-and-github-pages]]. CF Pages = apps/PWAs/websites; GitHub Pages = software landing pages. Both donation-OK.
