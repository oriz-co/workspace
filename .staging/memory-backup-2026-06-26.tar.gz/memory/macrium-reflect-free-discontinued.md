---
name: macrium-reflect-free-discontinued
description: "Macrium Reflect Free was discontinued January 2024. Use Windows built-in Backup-and-Restore, Hasleo Backup Suite Free, AOMEI Backupper Free, or Veeam Agent Free instead."
metadata: 
  node_type: memory
  type: reference
  originSessionId: dfd8f5bc-c2a5-4696-91a4-ea972dce2c5f
---

Macrium Reflect Free edition was discontinued in January 2024 — the free tier no longer receives new downloads or updates. For Windows full-disk-image backup, current free options: Windows built-in Backup-and-Restore (Win10/11), Hasleo Backup Suite Free, AOMEI Backupper Standard (Free), Veeam Agent for Microsoft Windows Free. Recorded 2026-06-25.
