---
name: openmodel-shim-api-deleted
description: openmodel-shim-api repo deleted 2026-06-25 — kept freellmapi + omniroute only
metadata: 
  node_type: memory
  type: project
  originSessionId: dfd8f5bc-c2a5-4696-91a4-ea972dce2c5f
---

openmodel-shim-api deleted from oriz-org + umbrella + filesystem on 2026-06-25. The 3-LLM-shim experiment narrowed to 2 (freellmapi + omniroute). Related: [[no-auth-in-apps-or-apis]].
