---
name: no-card-on-file-prepaid-escape
description: "The family-wide \"no card on file\" rule has one official escape hatch — one-time prepaid fees paid via prepaid PayPal balance. Currently used for Chrome Web Store ($5) and now Play Store ($25). No recurring subscriptions, ever."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 9c8c6cbf-7bf4-4c84-be72-bb13eaff802a
---

User direction 2026-06-21: when asked whether the Play Store $25 one-time fee violates [[no-card-on-file]], user picked "Pay $25 once, prepaid" not "skip the store entirely." Reaffirmed for Chrome Web Store $5 ("ALREADY a precedent").

**Why:** Distribution reach matters more than fee purity. The rule was "no recurring card billing" not "no money ever." Prepaid PayPal balance preserves the no-recurring-charges spirit.

**How to apply:**
- One-time prepaid fees are OK when distribution channel reach justifies them (Play Store, Chrome Web Store).
- Recurring fees stay banned (Apple Developer Program $99/yr, Stripe Atlas $500/yr, AWS account-on-file, etc.).
- Free tiers with credit card required for verification: still banned (Vercel, Render, Fly, etc.).
- When proposing a paid service in a question, default-recommend the "skip if recurring, prepaid if one-time" stance, not blanket rejection.

Knowledge: [[rules/no-card-on-file]], and the new [[decisions/architecture/pwabuilder-as-primary-converter]] which uses both Play + Microsoft + CWS.

Related: [[pwabuilder-primary-converter]], [[ios-pwa-only-no-mac]].
