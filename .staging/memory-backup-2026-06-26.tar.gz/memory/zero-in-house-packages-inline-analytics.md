---
name: zero-in-house-packages-inline-analytics
description: Zero in-house npm packages. Analytics inlined per app via <script> tags. Stack — CF Web Analytics + MS Clarity + PostHog.
metadata: 
  node_type: memory
  type: project
  originSessionId: dfd8f5bc-c2a5-4696-91a4-ea972dce2c5f
---

- All 23 in-house npm packages archived 2026-06-25. Zero survive on oriz-org.
- Analytics is inline: each app's `BaseLayout.astro` hardcodes 3 `<script>` tags.
- Stack picked (all free, all no-card-on-file):
  1. **Cloudflare Web Analytics** — already on CF, real-time pageviews + country. 1 line.
  2. **Microsoft Clarity** — heatmaps + session replay + dead/rage clicks. 1 line.
  3. **PostHog Cloud** — funnels + retention + product analytics. 3 lines. Free up to 1M events/mo.
- Total: ~4 lines per app. Per-app tokens in `.env`. Different apps can use different tokens.
- Future rule: build a new in-house package ONLY when ≥3 apps need the same logic AND no community equivalent exists.
- Blog grandfathered: keeps its 4 `@chirag127/*` deps (archived packages still installable from npm).
- Supersedes: [[one-package-only-analytics]] (locked 2026-06-25, reversed same day).
