---
name: no-card-rule-veto-history
description: Services killed by the no-card-on-file rule — running list
metadata: 
  node_type: memory
  type: reference
  originSessionId: dfd8f5bc-c2a5-4696-91a4-ea972dce2c5f
---

- Cloudflare R2 — killed in object-storage-split decision
- Vercel Pro — killed when considering hosting tiers
- Auth0 — killed in auth-backend grill
- Clerk Pro — would be killed at 10k MAU; hence the 5000 MAU migration trigger
- Macrium Reflect Free — discontinued, unrelated to card rule but listed for completeness
- Rule: [[no-card-on-file-prepaid-escape]] is absolute
