---
name: auth-firebase-login-and-account-subdomains
description: login.oriz.in = auth flow page (Microsoft-style). account.oriz.in = post-auth dashboard (Google-style). Both Firebase Auth via CF Worker.
metadata: 
  node_type: memory
  type: project
  originSessionId: dfd8f5bc-c2a5-4696-91a4-ea972dce2c5f
---

Two auth-related subdomains: `login.oriz.in` runs the sign-in flow (modeled on login.microsoftonline.com — pure auth, redirects out after) and `account.oriz.in` is the post-auth dashboard for managing profile/sessions/connected apps (modeled on myaccount.google.com). Both are Firebase Auth backed, fronted by a Cloudflare Worker for session/cookie handling. Locked 2026-06-25.

**SUPERSEDED 2026-06-25** by [[auth-clerk-with-emergency-migrate]]. Switched to Clerk for `<UserProfile/>` DX win; reverts to Firebase before crossing 5000 MAU.
