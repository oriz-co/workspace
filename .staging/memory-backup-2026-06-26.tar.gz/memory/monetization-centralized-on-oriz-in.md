---
name: monetization-centralized-on-oriz-in
description: Razorpay checkout lives ONLY on oriz.in/pricing. Apps redirect for paid upgrades. Single merchant.
metadata: 
  node_type: memory
  type: project
  originSessionId: 9c8c6cbf-7bf4-4c84-be72-bb13eaff802a
---

Razorpay checkout exists on oriz.in/pricing only. Every app's "Upgrade" CTA redirects to `https://oriz.in/pricing?app=<slug>&return=<url>`. Razorpay structurally forbids multiple merchant accounts per business PAN, so this is the only legal shape. Sign-in encouraged everywhere to capture analytics; strictly required for: Pro/Max features, stateful apps (journal, financial-cards, omni-post, packages-catalog), settings persistence. Stateless tools (PDF, dice, QR, currency) allow anonymous use. Locked 2026-06-23. Decision: knowledge/decisions/architecture/monetization-centralized-on-oriz-in.md.

**SUPERSEDED 2026-06-25** by [[donations-only-no-pro-no-ads]]. No Pro tier exists anymore; donations only.
