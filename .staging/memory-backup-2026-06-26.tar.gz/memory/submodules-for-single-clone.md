---
name: submodules-for-single-clone
description: "Umbrella repo c:\\D\\oriz uses git submodules so `git clone --recurse-submodules` pulls everything in one command. OK at <50 submodules."
metadata: 
  node_type: memory
  type: project
  originSessionId: dfd8f5bc-c2a5-4696-91a4-ea972dce2c5f
---

`c:\D\oriz` is the umbrella repo; each fleet repo is added as a git submodule. `git clone --recurse-submodules https://github.com/oriz-org/oriz` pulls the whole fleet in one command. Submodule performance is acceptable below ~50 entries (current scope fits). Locked 2026-06-25.
