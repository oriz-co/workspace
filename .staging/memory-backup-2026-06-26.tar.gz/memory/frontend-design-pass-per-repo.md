---
name: frontend-design-pass-per-repo
description: "Each category repo gets one `frontend-design` skill pass during scaffold to produce a per-repo palette/type/signature on a shared Tailwind+shadcn baseline."
metadata: 
  node_type: memory
  type: project
  originSessionId: dfd8f5bc-c2a5-4696-91a4-ea972dce2c5f
---

During each category repo's scaffold, run the `frontend-design` skill once to generate that repo's distinct palette, type scale, and visual signature — all on top of the shared Tailwind+shadcn baseline ([[framework-astro-react-tailwind-shadcn]]). Result: repos feel related but not identical. Locked 2026-06-25.
