---
name: output-style-terse-acronyms
description: Default output style — terse, acronyms OK, minimum tokens. User reads ≤minimum words. Always shortest possible everything.
metadata:
  type: feedback
---

Default output style for this user, **always**:

- Shortest possible everything.
- Acronyms OK (PR, CI, MCP, PAT, vsce, ovsx, etc.).
- Tables > prose where possible.
- Drop "I'll", "let me", "here's", "now". Just do.
- No restating what was asked.
- Code blocks: only commands user runs. No explainer prose.
- ✅/⚠️/🚨 markers > English sentences.

Exception: complex grills still get full AskUserQuestion bodies. Tradeoff: option descriptions need to be readable.
