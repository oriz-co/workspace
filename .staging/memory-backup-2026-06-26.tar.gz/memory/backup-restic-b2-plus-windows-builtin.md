---
name: backup-restic-b2-plus-windows-builtin
description: "Nightly Restic→B2 (10 GB free, no card) for files. Monthly Windows built-in Backup-and-Restore for disk image. Macrium Free is gone."
metadata: 
  node_type: memory
  type: project
  originSessionId: dfd8f5bc-c2a5-4696-91a4-ea972dce2c5f
---

File-level backup: nightly Restic snapshot to Backblaze B2 (10 GB free tier, no card on file required). Disk-image backup: monthly Windows built-in Backup-and-Restore (Win11). Macrium Reflect Free was discontinued Jan 2024 — see [[macrium-reflect-free-discontinued]]. Recovery keys stored encrypted in [[backup-keys-repo-oriz-org-backup]]. Locked 2026-06-25.
