---
name: framework-astro-react-tailwind-shadcn
description: Default stack for every new app — Astro shell + React island + Tailwind + shadcn/ui. React chosen over Preact for ecosystem.
metadata: 
  node_type: memory
  type: project
  originSessionId: dfd8f5bc-c2a5-4696-91a4-ea972dce2c5f
---

Every new app scaffolds with Astro (shell, MPA/SSG default) + React islands for interactivity + Tailwind for styling + shadcn/ui for component primitives. React picked over Preact for library ecosystem compatibility — see [[react-ecosystem-over-bundle-size]]. Locked 2026-06-25.
